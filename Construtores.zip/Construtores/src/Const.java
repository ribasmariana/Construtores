public class Const {
    public static void main(String[]args){
        Cliente cliente = new Cliente("Maria Luiza", "marialuiza@gmail.com");
        System.out.println(cliente);

        Cliente cliente1 = new Cliente("Maria Luiza", "marialuiza@gmail.com", "Centro");
        System.out.println(cliente1);

        Cliente cliente2 = new Cliente("Maria Luiza", "marialuiza@gmail.com", "Centro", 29);
        System.out.println(cliente2);

        Cliente cliente3 = new Cliente("Maria Luiza", "marialuiza@gmail.com", "Centro", 29, 53.8);
        System.out.println(cliente3);

        Cliente cliente4 = new Cliente("Maria Luiza", "marialuiza@gmail.com", "Centro", 29, 53.8, 1.58);
        System.out.println(cliente4);

    }
}
