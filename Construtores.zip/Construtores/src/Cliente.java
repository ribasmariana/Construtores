public class Cliente {
    String nome;
    String email;
    String endereco;
    Integer idade;
    Double peso;
    Double altura;

    public Cliente(){}

    public Cliente(String nome, String email){
        this.nome = nome;
        this.email = email;
        this.endereco = "Endereço não informado!";
    }

    public Cliente(String nome, String email, String endereco){
        this.nome = nome;
        this.email = email;
        this.endereco = endereco;
    }

    public Cliente(String nome, String email, String endereco, Integer idade) {
        this.nome = nome;
        this.email = email;
        this.endereco = endereco;
        this.idade = idade;
    }
    public Cliente(String nome, String email, String endereco, Integer idade, Double peso){
        this.nome = nome;
        this.email = email;
        this.endereco = endereco;
        this.idade = idade;
        this.peso = peso;
    }

    public Cliente(String nome, String email, String endereco, Integer idade, Double peso, Double altura){
        this.nome = nome;
        this.email = email;
        this.endereco = endereco;
        this.idade = idade;
        this.peso = peso;
        this.altura = altura;
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "nome='" + nome + '\'' +
                ", email='" + email + '\'' +
                ", endereco='" + endereco + '\'' +
                ", idade=" + idade +
                ", peso=" + peso +
                ", altura=" + altura +
                '}';
    }
}

